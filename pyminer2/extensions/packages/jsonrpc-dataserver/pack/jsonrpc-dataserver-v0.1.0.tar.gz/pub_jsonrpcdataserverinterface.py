class JsonrpcDataserverInterface(BaseInterface):

